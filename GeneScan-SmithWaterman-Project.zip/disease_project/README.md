# GeneScan: DNA Mutation & Disease Variant Detector (Smith–Waterman)

Java implementation combining a **Suffix Array + Kasai LCP array** (CO2 — String
Algorithms) exact-match stage with a **Smith–Waterman** (CO3 — Advanced Dynamic
Programming) local-alignment stage to compare a **healthy reference** DNA/protein
sequence against a **patient sample**, in order to detect disease-associated
mutations (point mutations and indels).

The demo uses the real, textbook example of **Sickle Cell Anaemia**: a single
point mutation in the HBB gene (codon `GAG` → `GTG`) that changes amino acid 6
of the beta-globin protein from Glutamic acid to Valine. It also includes an
illustrative in-frame-deletion case modelled on the **Cystic Fibrosis** ΔF508
mutation, and a batch mode that screens 100 synthetic patient samples against
the healthy reference and flags which ones carry the mutation.

See [`DESCRIPTION.md`](./DESCRIPTION.md) for the full write-up (algorithms used, syllabus
mapping, design decisions) and [`DSA-3_ABSTRACT.pdf`](./DSA-3_ABSTRACT.pdf) for the
original project abstract, problem statement, and proposed functionalities.

## Project structure
```
.
├── DESCRIPTION.md          # Full project description + CO2/CO3 mapping
├── DSA-3_ABSTRACT.pdf      # Abstract / problem statement / proposed functionalities
├── src/
│   ├── Main.java            # Demo driver (DNA case, protein case, performance analysis)
│   ├── SmithWaterman.java   # CO3: local alignment DP + traceback
│   ├── SuffixArrayLCP.java  # CO2: suffix array (prefix doubling) + Kasai LCP
│   ├── SequenceValidator.java
│   └── AlignmentResult.java
└── output/
    └── sample_output.txt    # Captured output from an actual run
```

## Requirements
- JDK 17+ (developed/tested on JDK 21)

## Build & run
```bash
cd src
javac *.java -d ../out
cd ../out
java Main
```

## What it does
1. Validates each healthy/patient sequence pair as DNA or protein.
2. **CO2 stage** — builds a suffix array of `healthy + separator + patient` and its LCP
   array (Kasai's algorithm) to find the longest exact common (conserved) substring
   between the two.
3. **CO3 stage** — runs Smith–Waterman with configurable match/mismatch/gap scores to
   find the best-scoring local alignment (tolerating mismatches and gaps), then prints
   the aligned sequences, score, match/mismatch/gap counts, percentage similarity, and
   (for Case 1) the DP matrix. Any mismatches/gaps are reported as detected mutations.
4. Three worked cases: Sickle Cell Anaemia at the DNA level, the same mutation at the
   protein level, and an illustrative Cystic-Fibrosis-style deletion.
5. A performance analysis, timing Smith–Waterman over sequence lengths 100 → 1600 to
   show its O(n·m) scaling.
6. A 100-sample batch screening run: synthetic patient DNA samples are generated from
   the healthy HBB reference, each aligned against it, and flagged as
   `MUTATION DETECTED` or `NORMAL`, with a summary of how many carriers were found.

## Sample output
See [`output/sample_output.txt`](./output/sample_output.txt) for a full captured run,
including all three cases, the performance table, and the 100-sample screening batch.

## Team
- B. Jamuna — 2520030408
- B. Pemesh — 2520030388
- P. Anuradha Nandini — 2520030171
