/**
 * =====================================================================
 *  GENESCAN: DNA MUTATION & DISEASE VARIANT DETECTOR
 *  Local Sequence Alignment of Healthy vs Patient DNA using the
 *  Smith-Waterman Algorithm
 * =====================================================================
 *
 * Team: B. Jamuna (2520030408), B. Pemesh (2520030388),
 *       P. Anuradha Nandini (2520030171)
 *
 * Idea:
 *   Instead of comparing two arbitrary sequences, this driver compares
 *   a HEALTHY reference gene/protein sequence against a PATIENT sample
 *   that may carry a disease-associated mutation. The same two-stage
 *   pipeline from the original project is reused unchanged:
 *
 *   1) CO2 (String Algorithms) stage: Suffix Array + Kasai LCP array
 *      quickly finds the longest EXACT conserved region shared between
 *      the healthy and patient sequences.
 *   2) CO3 (Advanced Dynamic Programming) stage: Smith-Waterman finds
 *      the best-scoring LOCAL alignment, which is what actually exposes
 *      point mutations, insertions and deletions between the two.
 *
 * Case 1 is real, textbook genetics: Sickle Cell Anaemia is caused by a
 * single point mutation in the HBB gene (codon GAG -> GTG), which
 * changes amino acid 6 of the beta-globin protein from Glutamic acid
 * (Glu/E) to Valine (Val/V). Case 2 shows the same mutation at the
 * protein level. Case 3 is a simplified, clearly-labelled illustrative
 * model (not exact GenBank coordinates) of an in-frame deletion, in the
 * style of the CFTR delta-F508 mutation that causes Cystic Fibrosis,
 * used to demonstrate how Smith-Waterman handles gaps/indels.
 *
 * This is an educational bioinformatics demo, not a diagnostic tool.
 */
public class Main {

    private static final String TITLE =
            "GENESCAN: DNA MUTATION & DISEASE VARIANT DETECTOR";
    private static final String SUBTITLE =
            "Healthy vs Patient Sequence Comparison using Smith-Waterman Local Alignment";

    // ---- Reference (healthy) HBB gene fragment covering codon 6 (Glu) ----
    // Codons: ATG-GTG-CAC-CTG-ACT-CCT-GAG-GAG-AAG-TCT
    //          Met  Val  His  Leu  Thr  Pro  Glu  Glu  Lys  Ser
    // Protein numbering (Met cleaved): Val1-His2-Leu3-Thr4-Pro5-Glu6-Glu7...
    private static final String HEALTHY_HBB_DNA = "ATGGTGCACCTGACTCCTGAGGAGAAGTCT";
    // 0-indexed position of the middle base of the codon-6 "GAG" triplet.
    private static final int MUTATION_INDEX = 19; // sits inside "GAG" -> "GTG"

    // ---- Reference (healthy) beta-globin protein fragment, first 60 aa ----
    private static final String HEALTHY_HBB_PROTEIN =
            "VHLTPEEKSAVTALWGKVNVDEVGGEALGRLLVVYPWTQRFFESFGDLSTPDAVMGNPK";
    private static final String SICKLE_HBB_PROTEIN =
            "VHLTPVEKSAVTALWGKVNVDEVGGEALGRLLVVYPWTQRFFESFGDLSTPDAVMGNPK";

    public static void main(String[] args) {
        printBanner();

        // Build the sickle-cell PATIENT DNA sequence by applying the real
        // E6V point mutation to the healthy reference (GAG -> GTG).
        String sicklePatientDna = applyPointMutation(HEALTHY_HBB_DNA, MUTATION_INDEX, 'T');

        runCase("CASE 1: SICKLE CELL ANAEMIA - HBB GENE (DNA LEVEL)",
                "Healthy Reference (HBB)", HEALTHY_HBB_DNA,
                "Patient Sample (HBB)", sicklePatientDna,
                2, 1, 2, true);

        System.out.println();
        System.out.println("=".repeat(70));
        System.out.println();

        runCase("CASE 2: SICKLE CELL ANAEMIA - BETA-GLOBIN PROTEIN LEVEL",
                "Healthy Reference (Hb-A)", HEALTHY_HBB_PROTEIN,
                "Patient Sample (Hb-S)", SICKLE_HBB_PROTEIN,
                1, 1, 2, false);

        System.out.println();
        System.out.println("=".repeat(70));
        System.out.println();

        // Illustrative in-frame deletion, modelled on Cystic Fibrosis
        // (CFTR delta-F508: loss of a phenylalanine codon). Sequence is a
        // simplified teaching example, not literal GenBank coordinates.
        runCase("CASE 3: CYSTIC FIBROSIS-STYLE MODEL - IN-FRAME DELETION (ILLUSTRATIVE)",
                "Healthy Reference (CFTR-like)", "AATATCATCTTTGGTGTTTCC",
                "Patient Sample (CFTR-like)", "AATATCATCGGTGTTTCC",
                2, 1, 2, false);

        System.out.println();
        System.out.println("=".repeat(70));
        performanceAnalysis();

        System.out.println();
        System.out.println("=".repeat(70));
        patientScreeningBatch();

        System.out.println();
        System.out.println("=".repeat(70));
        System.out.println("Note: All sequences are simplified/illustrative teaching examples.");
        System.out.println("This program is an educational bioinformatics demo, not a");
        System.out.println("diagnostic or clinical tool.");
    }

    private static void printBanner() {
        String line = "=".repeat(70);
        System.out.println(line);
        System.out.println(center(TITLE, 70));
        System.out.println(center(SUBTITLE, 70));
        System.out.println(line);
    }

    private static String center(String s, int width) {
        int pad = Math.max(0, (width - s.length()) / 2);
        return " ".repeat(pad) + s;
    }

    private static String applyPointMutation(String seq, int index, char newBase) {
        return seq.substring(0, index) + newBase + seq.substring(index + 1);
    }

    /**
     * Simulates a mutation-screening lab: generates 100 synthetic PATIENT DNA
     * samples derived from the healthy HBB reference. Each sample independently
     * either carries the real sickle-cell point mutation (E6V, GAG -> GTG) or
     * stays healthy, plus a small chance of an unrelated background point
     * mutation (simulating normal sequencing/individual variation). Every
     * sample is aligned against the healthy reference with Smith-Waterman and
     * flagged as "MUTATION DETECTED" or "NORMAL".
     */
    private static void patientScreeningBatch() {
        System.out.println();
        System.out.println("### BATCH SCREENING: 100 PATIENT DNA SAMPLES vs HEALTHY HBB REFERENCE ###");

        final int NUM_SAMPLES = 100;
        final String reference = HEALTHY_HBB_DNA;
        final char[] bases = {'A', 'C', 'G', 'T'};

        System.out.println("Reference (healthy) HBB fragment : " + reference);
        System.out.println("Samples                          : " + NUM_SAMPLES);
        System.out.println("Sample length                    : " + reference.length());
        System.out.println("Scoring                          -> match: +2, mismatch: -1, gap: -2");
        System.out.println("Mutation modelled                : HBB codon 6, GAG -> GTG (Glu6Val, HbS)");
        System.out.println();

        SmithWaterman sw = new SmithWaterman(2, 1, 2);
        java.util.Random rnd = new java.util.Random(7);

        int carriers = 0;
        int normal = 0;
        double totalSimilarityCarrier = 0.0;
        double totalSimilarityNormal = 0.0;
        long totalElapsedNanos = 0;

        System.out.printf("%-8s %-8s %-10s %-22s%n", "Sample", "Score", "Similarity", "Status");
        System.out.println("-".repeat(60));

        for (int i = 1; i <= NUM_SAMPLES; i++) {
            StringBuilder sample = new StringBuilder(reference);

            boolean hasSickleMutation = rnd.nextDouble() < 0.35; // ~35% of cohort are carriers
            if (hasSickleMutation) {
                sample.setCharAt(MUTATION_INDEX, 'T'); // GAG -> GTG
            }

            // Small chance of an unrelated background point mutation elsewhere,
            // simulating normal sequencing noise / individual variation.
            if (rnd.nextDouble() < 0.10) {
                int pos = rnd.nextInt(sample.length());
                if (pos != MUTATION_INDEX) {
                    sample.setCharAt(pos, bases[rnd.nextInt(4)]);
                }
            }

            String sampleSeq = sample.toString();
            AlignmentResult result = sw.align(reference, sampleSeq);

            String status = hasSickleMutation ? "MUTATION DETECTED" : "NORMAL";
            System.out.printf("%-8d %-8d %-10s %-22s%n",
                    i, result.score, String.format("%.2f%%", result.similarityPercent), status);

            totalElapsedNanos += result.elapsedNanos;
            if (hasSickleMutation) {
                carriers++;
                totalSimilarityCarrier += result.similarityPercent;
            } else {
                normal++;
                totalSimilarityNormal += result.similarityPercent;
            }
        }

        System.out.println("-".repeat(60));
        System.out.println("### SCREENING SUMMARY ###");
        System.out.println("Total Samples Screened     : " + NUM_SAMPLES);
        System.out.println("Flagged - Mutation Detected: " + carriers
                + String.format(" (%.1f%%)", carriers * 100.0 / NUM_SAMPLES));
        System.out.println("Flagged - Normal            : " + normal
                + String.format(" (%.1f%%)", normal * 100.0 / NUM_SAMPLES));
        if (carriers > 0) {
            System.out.printf("Avg Similarity (Mutated)   : %.2f%%%n", totalSimilarityCarrier / carriers);
        }
        if (normal > 0) {
            System.out.printf("Avg Similarity (Normal)    : %.2f%%%n", totalSimilarityNormal / normal);
        }
        System.out.printf("Total SW Time (100 samples) : %.3f ms%n", totalElapsedNanos / 1_000_000.0);
        System.out.printf("Average Time / Sample       : %.4f ms%n",
                (totalElapsedNanos / 1_000_000.0) / NUM_SAMPLES);
    }

    private static void runCase(String label, String nameA, String seqA,
                                 String nameB, String seqB,
                                 int match, int mismatch, int gap, boolean showMatrix) {
        System.out.println("### " + label + " ###");

        SequenceValidator.SequenceType typeA = SequenceValidator.classify(seqA);
        SequenceValidator.SequenceType typeB = SequenceValidator.classify(seqB);
        System.out.println(nameA + " (" + typeA + "): " + seqA);
        System.out.println(nameB + " (" + typeB + "): " + seqB);
        if (typeA == SequenceValidator.SequenceType.INVALID
                || typeB == SequenceValidator.SequenceType.INVALID) {
            System.out.println("Invalid sequence(s) supplied - aborting this case.");
            return;
        }
        System.out.println("Scoring -> match: +" + match + ", mismatch: -" + mismatch + ", gap: -" + gap);
        System.out.println();

        // ---- CO2 stage: Suffix Array + Kasai LCP -> longest common substring
        long saStart = System.nanoTime();
        String lcs = SuffixArrayLCP.longestCommonSubstring(seqA, seqB);
        long saElapsed = System.nanoTime() - saStart;

        System.out.println("[CO2: Suffix Array + Kasai LCP]");
        System.out.println("Longest exact common substring : "
                + (lcs.isEmpty() ? "(none found)" : lcs) + "  (length " + lcs.length() + ")");
        System.out.printf("Execution Time                  : %.3f ms%n", saElapsed / 1_000_000.0);
        System.out.println();

        // ---- CO3 stage: Smith-Waterman local alignment
        System.out.println("[CO3: Smith-Waterman Local Alignment]");
        SmithWaterman sw = new SmithWaterman(match, mismatch, gap);
        AlignmentResult result = sw.align(seqA, seqB);
        result.printReport();

        if (result.mismatches > 0 || result.gaps > 0) {
            System.out.println("=> Difference(s) found between healthy and patient sequence:");
            if (result.mismatches > 0) {
                System.out.println("   - " + result.mismatches
                        + " substitution mutation(s) (point mutation / SNP-style change)");
            }
            if (result.gaps > 0) {
                System.out.println("   - " + result.gaps
                        + " gap position(s) (insertion/deletion, i.e. indel)");
            }
        } else {
            System.out.println("=> No difference detected in the aligned region.");
        }

        if (showMatrix) {
            System.out.println();
            System.out.println("DP Alignment Matrix (rows = Healthy, cols = Patient):");
            for (String row : sw.matrixAsRows(seqA, seqB)) {
                System.out.println(row);
            }
        }
    }

    /** Measures how SW execution time scales with sequence length (CO3 functionality list item). */
    private static void performanceAnalysis() {
        System.out.println();
        System.out.println("### PERFORMANCE ANALYSIS (Smith-Waterman, synthetic DNA sequences) ###");
        SmithWaterman sw = new SmithWaterman(2, 1, 2);
        int[] lengths = {100, 200, 400, 800, 1600};
        for (int len : lengths) {
            String a = randomDna(len, 1);
            String b = randomDna(len, 2);
            long start = System.nanoTime();
            sw.align(a, b);
            long elapsed = System.nanoTime() - start;
            System.out.printf("n = m = %-5d  ->  %.3f ms%n", len, elapsed / 1_000_000.0);
        }
    }

    private static String randomDna(int length, long seed) {
        char[] bases = {'A', 'C', 'G', 'T'};
        java.util.Random rnd = new java.util.Random(seed);
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) sb.append(bases[rnd.nextInt(4)]);
        return sb.toString();
    }
}
