/** Simple data holder for a Smith-Waterman alignment result. */
public class AlignmentResult {
    public final String alignedA;
    public final String alignedB;
    public final int score;
    public final int matches;
    public final int mismatches;
    public final int gaps;
    public final double similarityPercent;
    public final int startI, startJ, endI, endJ;
    public final long elapsedNanos;

    public AlignmentResult(String alignedA, String alignedB, int score, int matches,
                            int mismatches, int gaps, double similarityPercent,
                            int startI, int startJ, int endI, int endJ, long elapsedNanos) {
        this.alignedA = alignedA;
        this.alignedB = alignedB;
        this.score = score;
        this.matches = matches;
        this.mismatches = mismatches;
        this.gaps = gaps;
        this.similarityPercent = similarityPercent;
        this.startI = startI;
        this.startJ = startJ;
        this.endI = endI;
        this.endJ = endJ;
        this.elapsedNanos = elapsedNanos;
    }

    public void printReport() {
        System.out.println("Alignment Score        : " + score);
        System.out.println("Aligned Sequence A      : " + alignedA);
        System.out.println("Match Indicators        : " + buildMatchLine());
        System.out.println("Aligned Sequence B      : " + alignedB);
        System.out.println("Matches                 : " + matches);
        System.out.println("Mismatches              : " + mismatches);
        System.out.println("Gaps                    : " + gaps);
        System.out.printf ("Percentage Similarity   : %.2f%%%n", similarityPercent);
        System.out.println("Region in Sequence A     : [" + (startI + 1) + ", " + endI + "]");
        System.out.println("Region in Sequence B     : [" + (startJ + 1) + ", " + endJ + "]");
        System.out.printf ("Execution Time           : %.3f ms%n", elapsedNanos / 1_000_000.0);
    }

    private String buildMatchLine() {
        StringBuilder sb = new StringBuilder();
        for (int k = 0; k < alignedA.length(); k++) {
            char a = alignedA.charAt(k), b = alignedB.charAt(k);
            sb.append(a != '-' && b != '-' && a == b ? '|' : ' ');
        }
        return sb.toString();
    }
}
