import java.util.Arrays;

/**
 * Suffix Array construction (prefix-doubling, O(n log^2 n)) and the
 * Kasai algorithm for the Longest Common Prefix (LCP) array in O(n).
 *
 * Module: CO2 - String Algorithms
 * Topics: "Suffix arrays: definition ... practical O(n log^2 n)
 *          implementation." and "Longest Common Prefix (LCP) array:
 *          the Kasai algorithm in linear time given a suffix array."
 *
 * In this project the suffix array + LCP array are used to find the
 * LONGEST COMMON SUBSTRING (an exact, ungapped conserved region) shared
 * by two sequences before the Smith-Waterman (CO3) algorithm is used to
 * find the best-scoring alignment that also tolerates mismatches/gaps.
 * This gives the project one fast exact-matching stage (CO2) feeding
 * into one approximate/scored alignment stage (CO3).
 */
public class SuffixArrayLCP {

    private final String text;
    private final int n;
    private int[] suffixArray;
    private int[] rank;
    private int[] lcp;

    public SuffixArrayLCP(String text) {
        this.text = text;
        this.n = text.length();
        buildSuffixArray();
        buildLcpArrayKasai();
    }

    /** Prefix-doubling suffix array construction: O(n log^2 n). */
    private void buildSuffixArray() {
        Integer[] sa = new Integer[n];
        int[] rankArr = new int[n];
        int[] tempRank = new int[n];

        for (int i = 0; i < n; i++) {
            sa[i] = i;
            rankArr[i] = text.charAt(i);
        }

        for (int k = 1; k < n; k *= 2) {
            final int kk = k;
            final int[] r = rankArr;
            java.util.Comparator<Integer> cmp = (a, b) -> {
                if (r[a] != r[b]) return Integer.compare(r[a], r[b]);
                int ra = a + kk < n ? r[a + kk] : -1;
                int rb = b + kk < n ? r[b + kk] : -1;
                return Integer.compare(ra, rb);
            };
            Arrays.sort(sa, cmp);

            tempRank[sa[0]] = 0;
            for (int i = 1; i < n; i++) {
                tempRank[sa[i]] = tempRank[sa[i - 1]] + (cmp.compare(sa[i - 1], sa[i]) < 0 ? 1 : 0);
            }
            rankArr = tempRank.clone();

            if (rankArr[sa[n - 1]] == n - 1) break; // all ranks unique -> fully sorted
        }

        suffixArray = new int[n];
        for (int i = 0; i < n; i++) suffixArray[i] = sa[i];
        this.rank = rankArr;
    }

    /** Kasai's algorithm: builds the LCP array in O(n) given the suffix array. */
    private void buildLcpArrayKasai() {
        lcp = new int[n];
        int[] invSuffix = new int[n];
        for (int i = 0; i < n; i++) invSuffix[suffixArray[i]] = i;

        int h = 0;
        for (int i = 0; i < n; i++) {
            if (invSuffix[i] > 0) {
                int j = suffixArray[invSuffix[i] - 1];
                while (i + h < n && j + h < n && text.charAt(i + h) == text.charAt(j + h)) {
                    h++;
                }
                lcp[invSuffix[i]] = h;
                if (h > 0) h--;
            } else {
                h = 0;
            }
        }
    }

    public int[] getSuffixArray() { return suffixArray; }
    public int[] getLcpArray() { return lcp; }

    /**
     * Finds the longest substring common to seqA and seqB using the
     * suffix array + LCP array of (seqA + SEPARATOR + seqB), only
     * accepting LCP values between suffixes that come from different
     * original strings (classic generalized-LCS technique).
     */
    public static String longestCommonSubstring(String seqA, String seqB) {
        char sep = '\u0001';
        String combined = seqA + sep + seqB;
        SuffixArrayLCP sal = new SuffixArrayLCP(combined);

        int splitIndex = seqA.length(); // index of the separator character
        int bestLen = 0, bestPos = -1;

        int[] sa = sal.getSuffixArray();
        int[] lcpArr = sal.getLcpArray();

        for (int i = 1; i < sa.length; i++) {
            boolean prevFromA = sa[i - 1] < splitIndex;
            boolean currFromA = sa[i] < splitIndex;
            if (prevFromA != currFromA && lcpArr[i] > bestLen) {
                bestLen = lcpArr[i];
                bestPos = sa[i];
            }
        }
        if (bestLen == 0) return "";
        return combined.substring(bestPos, bestPos + bestLen);
    }
}
